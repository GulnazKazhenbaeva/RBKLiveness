//
//  RBKLiveness.h
//  RBKLiveness
//
//  Created by Gulnaz on 12/29/20.
//  Copyright © 2020 rbk. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for RBKLiveness.
FOUNDATION_EXPORT double RBKLivenessVersionNumber;

//! Project version string for RBKLiveness.
FOUNDATION_EXPORT const unsigned char RBKLivenessVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RBKLiveness/PublicHeader.h>


